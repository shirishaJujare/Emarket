import { Component, OnInit } from '@angular/core';
import { Category } from '../category';
import { CatserviceService } from '../catservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-categorylist',
  templateUrl: './categorylist.component.html',
  styleUrls: ['./categorylist.component.scss']
})
export class CategorylistComponent implements OnInit {
  _categorylist: Category[] = [];


  constructor(private _service:CatserviceService, private _route:Router) { }

  ngOnInit() {
    this._service.fetchCategoryListFromRemote().subscribe(
      data=>{
        this._categorylist=data;
      },
      error=>console.log("exception occured")
    )
  }
goToAddCategory(){
  this._route.navigate(['/addcategory']);
}

goToEditCategory(id:number){
  console.log("id"+id);
  this._route.navigate(['/editcategory',id]);

}

goToViewCategory(id:number){
  console.log("id"+id);
  this._route.navigate(['/viewcategory',id]);
}

deleteCategory(id:number){
  this._service.deleteCategoryByIdFromRemote(id).subscribe(
    data => {
    console.debug("deleted successfully");
    this._route.navigate(['/categorylist'])
    },
    error => console.log("exception occured")
  )
}

}
