import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { CatserviceService } from '../catservice.service';
import {Category}from '../category';

@Component({
  selector: 'app-addcategory',
  templateUrl: './addcategory.component.html',
  styleUrls: ['./addcategory.component.scss']
})
export class AddcategoryComponent implements OnInit {
  category = new Category();

  constructor(private _route:Router,private _service:CatserviceService) { }

  ngOnInit() {
  }

  addcategoryformsubmit()
  {
    this._service.addcategoryToRemote(this.category).subscribe
    (
      data=>
            {
              console.log("data added successfullly");
              this._route.navigate(['categorylist']);
            },
            error=>console.log("error")
    )
  }

  gotolist(){
    console.log('go back');
    this._route.navigate(['categorylist']);
  }

  url: any; //Angular 11, for stricter type
	msg = "";
	
	//selectFile(event) { //Angular 8
	selectFile(event: any) { //Angular 11, for stricter type
		if(!event.target.files[0] || event.target.files[0].length == 0) {
			this.msg = 'You must select an image';
			return;
		}
		
		var mimeType = event.target.files[0].type;
		
		if (mimeType.match(/image\/*/) == null) {
			this.msg = "Only images are supported";
			return;
		}
		
		var reader = new FileReader();
		reader.readAsDataURL(event.target.files[0]);
		
		reader.onload = (_event) => {
			this.msg = "";
			this.url = reader.result; 
		}
	}

}
