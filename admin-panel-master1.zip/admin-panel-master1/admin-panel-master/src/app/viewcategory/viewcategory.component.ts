import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Category } from '../category';
import { CatserviceService } from '../catservice.service';

@Component({
  selector: 'app-viewcategory',
  templateUrl: './viewcategory.component.html',
  styleUrls: ['./viewcategory.component.scss']
})
export class ViewcategoryComponent implements OnInit {

  category = new Category();
  id:any;
  

  constructor(private _route:Router,private _service:CatserviceService, private _activatedRoute:ActivatedRoute) { }

  ngOnInit(){
    this.id =(this._activatedRoute.snapshot.paramMap.get('id'));
    this._service.fetchCategoryByIdFromRemote(this.id).subscribe
       (
        data =>{
                console.log("data received");
               this.category=data;
         }, 
         error =>console.log("exception occured")
      )
  }

   gotolist(){
    console.log('go back');
    this._route.navigate(['categorylist']);
  }
 



}
