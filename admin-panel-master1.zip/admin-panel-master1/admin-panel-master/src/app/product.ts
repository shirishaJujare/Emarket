export class Product {

    id:number;
   name:string;
    decs:string;
    image:string;
     price:string;
     category:string;

     constructor(id:number=0, name:string="", decs:string="", image:string="", price:string="",category:string="")
      {
       this.id=id;
       this.name=name;
       this.decs=decs;
       this.image=image;
       this.price=price;
       this.category=category;
     }
}
