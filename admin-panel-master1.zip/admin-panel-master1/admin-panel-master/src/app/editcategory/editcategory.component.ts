import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Category } from '../category';
import { CatserviceService } from '../catservice.service';

@Component({
  selector: 'app-editcategory',
  templateUrl: './editcategory.component.html',
  styleUrls: ['./editcategory.component.scss']
})
export class EditcategoryComponent implements OnInit {

  category = new Category();
  id:any;
  

  constructor(private _route:Router,private _service:CatserviceService, private _activatedRoute:ActivatedRoute) { }

  ngOnInit(){
    this.id =(this._activatedRoute.snapshot.paramMap.get('id'));
    this._service.fetchCategoryByIdFromRemote(this.id).subscribe
       (
        data =>{
                console.log("data received");
               this.category=data;
         }, 
         error =>console.log("exception occured")
      )
  }

  updateCategoryformsubmit()
  {
    this._service.addcategoryToRemote(this.category).subscribe
    (
      data=>
            {
              console.log("data added successfullly");
              this._route.navigate(['categorylist']);
            },
            error=>console.log("error")
    )
  }

  gotolist(){
    console.log('go back');
    this._route.navigate(['categorylist']);
  }

  //url; //Angular 8
	url: any; //Angular 11, for stricter type
	msg = "";
	
	//selectFile(event) { //Angular 8
	selectFile(event: any) { //Angular 11, for stricter type
		if(!event.target.files[0] || event.target.files[0].length == 0) {
			this.msg = 'You must select an image';
			return;
		}
		
		var mimeType = event.target.files[0].type;
		
		if (mimeType.match(/image\/*/) == null) {
			this.msg = "Only images are supported";
			return;
		}
		
		var reader = new FileReader();
		reader.readAsDataURL(event.target.files[0]);
		
		reader.onload = (_event) => {
			this.msg = "";
			this.url = reader.result; 
		}
	}
	
}


