import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Category } from './category';

@Injectable({
  providedIn: 'root'
})
export class CatserviceService {
  addCategoryToRemote: any;
  addUserToRemote(category: any) {
    throw new Error('Method not implemented.');
  }

  constructor(private _http:HttpClient) { }

  fetchCategoryListFromRemote():Observable<any>{
    return this._http.get<any>("http://localhost:8080/getcategorylist")
  }
 
  addcategoryToRemote(category:Category):Observable<any>{
    return this._http.post<any>("http://localhost:8080/addcategory",category);
  }

  fetchCategoryByIdFromRemote(id:number):Observable<any>{
    return this._http.get<any>("http://localhost:8080/getcategorybyid/"+id);
  }

  deleteCategoryByIdFromRemote(id:number):Observable<any>{
    return this._http.delete<any>("http://localhost:8080/deletecategorybyid/"+id);
  }
}
