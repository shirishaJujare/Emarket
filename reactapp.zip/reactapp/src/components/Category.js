import React from 'react'
import App from '../App'
import Category from './components/ca'

const category=() =>{
    return(
        <>
        <h1>category</h1>
        </>
    )
}


export default App;
