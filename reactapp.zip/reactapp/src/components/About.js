import React from 'react'
import { NavLink } from 'react-router-dom'
const About = () => {
return (
<div>
<div className="container py-5 my-5">
<div className="row">

<div className="col-md-6 d-flex justify-content-center">
<img src="/assets/images/about.png" alt="About Us" height="400px" width="600px" />
</div>
<div className="col-md-6">
<h1 className="text-primary fw-bold mb-4 ">About Us</h1>
<p className="lead mb-4">
E-commerce (electronic commerce) is the buying and selling of goods and services, or the transmitting of funds or data,
 over an electronic network, primarily the internet. The terms e-commerce and e-business are often used interchangeably.
 A website that allows people to buy and sell physical goods, services, and digital products over the internet
  rather than at a brick-and-mortar location. Through an e-commerce website, a business can process orders, accept payments,
manage shipping and logistics, and provide customer service.
</p>
<NavLink to="/contact" className="btn btn-outline-primary px-3">Contact Us</NavLink>
</div>
</div>
</div>





</div>
)
}
export default About