import React from 'react'
import { NavLink } from 'react-router-dom'

const Order = () => {
return (
    <div class="jumbotron text-center">
<h1 class="display-3">
    <p>Your order was successfully placed....</p>
        Thank You!</h1>


<p>
Having trouble? <NavLink to="/contact" href="">Contact us</NavLink>
</p>
<p class="lead">

<NavLink to="/home" className="btn btn-outline-primary mb-5 w-25 mx-auto">Continue To Homepage</NavLink>
</p>
</div>
)
}
export default Order