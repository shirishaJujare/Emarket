
import React, { Component } from 'react';
import axios from 'axios';



class Signup1 extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            name:'',
            email:'',
            password:'',
            confirmpassword:'',
            mobileno:0

         }
    }
    handelChange=event=>{
        this.setState({[event.target.name]:event.target.value})
    }
    handelSubmit=event=>{
        event.preventDefault()
        console.log(this.state);
        axios.post('http://localhost:8081/signup',this.state). then(res=>{
            console.log(res.data)
            window.location.replace("/Products")
        }).catch(
            err=>{
                console.log("data already present")
            }
        )
    }
    render(){
        const{name,email,password,confirmpassword,mobileno}=this.state;
    return(
        
<div >

<button type="button" className="btn btn-outline-dark float-right ms-2" data-bs-toggle="modal" data-bs-target="#signupModel" >
<span className="fa fa-user-plus me-1"></span> Register </button>




<div className="modal fade" id="signupModel" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div className="modal-dialog">
<div className="modal-content">
<div className="modal-header">
<h5 className="modal-title" id="exampleModalLabel">Register</h5>
<button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div className="modal-body">
{/* <button className="btn btn-dark w-100 mb-4">
<div className="fa fa-google me-2">
    <a href="https://www.google.com/"></a>
    </div>Sign up With Google
</button> */}
  <div class="dropdown-content">
      <div class="container" text-align="center">
<a href="https://accounts.google.com/servicelogin/signinchooser?flowName=GlifWebSignIn&flowEntry=ServiceLogin">Sign up with google
<img src="/assets/images/google.png"  width="40" height="40" ></img> </a>
</div>
</div>
<div class="dropdown-content">
      <div class="container" text-align="center">
<a href="https://www.facebook.com/login/">Sign up with Facebook
<img src="/assets/images/fb.png"  width="40" height="40" ></img> </a>
</div>
</div>

{/* <button className="btn btn-dark w-100 mb-4">
<span className="fa fa-facebook me-2"></span>Sign up With Facebook
</button> */}
<form onSubmit={this.handelSubmit}>
<div className="mb-3">
<label htmlFor="nam" className="form-label">Username</label>
<input type="text" className="form-control" name="name" value={name} id="nam" onChange={this.handelChange}/>

</div>
<div className="mb-3">
<label htmlFor="emailid" className="form-label">Email address</label>
<input type="email" className="form-control" id="emailid" name="email" value={email} aria-describedby="emailHelp" onChange={this.handelChange}/>
<div id="email" className="form-text">We'll never share your email with anyone else.</div>
</div>

<div className="mb-3">
<label htmlFor="pass" className="form-label">Password</label>
<input type="password" className="form-control" id="pass" name="password" value={password} onChange={this.handelChange} />
</div>
<div className="mb-3">
<label htmlFor="cpass" className="form-label">Confirmpassword</label>
<input type="password" className="form-control" id="cpass" name="confirmpassword" value={confirmpassword} onChange={this.handelChange}/ >
</div>
<div className="mb-3">
<label htmlFor="phno" className="form-label">Phonenumber</label>
<input type="number" className="form-control" id="phno" name="mobileno" value={mobileno} onChange={this.handelChange}/>

</div>

<button type="submit" className="btn btn-outline-dark w-100 mt-5">Submit</button>
</form>
</div>



</div>
</div>
</div>



</div>);

}
}
export default Signup1;
