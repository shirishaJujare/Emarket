const Products=[
  { 
   Number:id,
   String:name,
   String:decs,
   String:image,
   Number:price,
//   id:1,
//   name:"oneplus",
//   decs:"bestmobile",
//   price:82000
// },
// {
//     id:1,
//   name:"samsung",
//   decs:"worstmobile",
//   price:20000
},
]
export default Products;