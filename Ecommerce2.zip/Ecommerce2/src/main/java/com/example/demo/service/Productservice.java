package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Product;
import com.example.demo.model.Productmodel;
import com.example.demo.repository.Productrepository;
@Service
public class Productservice {
	@Autowired
	Productrepository repo;

	public Product getproducts(Product pm) {
		
		return repo.save(pm);
	}

	public List<Product> getallproducts() {
	      List<Product> list = repo.findAll();
		return list;
	}

	public Product getprobyid(int id) {
	
		Product pc;
		pc=repo.findById(id).get();
		return pc;
	}

}
