package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.ProductService;
import com.example.demo.model.Product;


@CrossOrigin(origins = {"http://localhost:4200", "http://localhost:3000"})
@RestController
public class ProductsContoller {
	@Autowired
	private ProductService service;
	
	
	
	@GetMapping("/getproductlist")
	@CrossOrigin(origins = {"http://localhost:4200", "http://localhost:3000"})
	public List<Product> fetchProductList(){
    List<Product> products = new ArrayList<Product>();
//login to fetch from the db;
    products = service.fetchproductList();
    return products;	
		
}
	
	@PostMapping("/addproduct")
	@CrossOrigin(origins = "http://localhost:4200")
	public Product saveProduct(@RequestBody Product product){  
  return  service.saveProductToDB(product);
		
}
	
	@GetMapping("/getproduct")
	@CrossOrigin(origins = "http://localhost:4200")
	public Product getProduct(@RequestBody Product product){  
  return  service.fetchProductToDB(product);
		
}
	
	
//	@PostMapping("/editproduct")
//	@CrossOrigin(origins = "http://localhost:4200")
//	public Product editProduct(@RequestBody Product product){  
//  return  service.saveProductToDB(product);
		
//}
	
	
	@GetMapping("/getproductbyid/{id}")
	@CrossOrigin(origins = {"http://localhost:4200", "http://localhost:3000"})
	public Product fetchProductById(@PathVariable int id){
		return service.fetchProductById(id).get();
		
}
	
	@DeleteMapping("/deleteproductbyid/{id}")
	@CrossOrigin(origins = "http://localhost:4200")
	public String DeleteProductById(@PathVariable int id){
  
  return  service.deleteProductById(id);
		
}
	
	
	
}
