import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgserviceService } from '../ngservice.service';
import { Product } from '../product';

@Component({
  selector: 'app-editproduct',
  templateUrl: './editproduct.component.html',
  styleUrls: ['./editproduct.component.css']
})
export class EditproductComponent implements OnInit {
 
  product=new Product();
  id:any;

  constructor(private _route:Router,private _service:NgserviceService, private _activatedRoute:ActivatedRoute) { }

   ngOnInit(){
 this.id = (this._activatedRoute.snapshot.paramMap.get('id'));
 this._service.fetchProductByidFromRemote(this.id).subscribe
    (
     data =>{
             console.log("data received");
            this.product=data;
      }, 
      error =>console.log("exception occured")
   )
//console.log(this._activatedRoute.snapshot.paramMap.get('id'));
  }
  

  updateproductformsubmit(){
    
    this._service.addProductToRemote(this.product).subscribe
    (
      data =>
      {
        console.log("data added sucessfully");
        this._route.navigate(['productlist']);
      },
     error => console.log("error")
    )
  }

  gotolist(){
    console.log('go back');
    this._route.navigate(['productlist']);
  }

  url: any; //Angular 11, for stricter type
	msg = "";
	
	//selectFile(event) { //Angular 8
	selectFile(event: any) { //Angular 11, for stricter type
		if(!event.target.files[0] || event.target.files[0].length == 0) {
			this.msg = 'You must select an image';
			return;
		}
		
		var mimeType = event.target.files[0].type;
		
		if (mimeType.match(/image\/*/) == null) {
			this.msg = "Only images are supported";
			return;
		}
		
		var reader = new FileReader();
		reader.readAsDataURL(event.target.files[0]);
		
		reader.onload = (_event) => {
			this.msg = "";
			this.url = reader.result; 
		}
	}
}
