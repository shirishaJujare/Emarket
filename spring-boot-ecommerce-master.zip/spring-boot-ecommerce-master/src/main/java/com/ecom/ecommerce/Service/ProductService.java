package com.ecom.ecommerce.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecom.ecommerce.model.Product;
import com.ecom.ecommerce.repository.ProductRepository;

@Service
public class ProductService {
	@Autowired
	private ProductRepository repo;
	public List<Product> fetchproductList(){
	return	repo.findAll();
		
	}

	public Product  saveProductToDB(Product product) 
	{
		return repo.save(product);
	}
	
	public Optional<Product>  fetchProductById(int id) 
	{
		return repo.findById(id);
	}
	
	public String deleteProductById(int id) 
	{
		String result;
		try {
		
		repo.deleteById(id);
		result="Products successfully deleted";
	}catch(Exception e) {
		result="Products with id is not  deleted";
	}
	return  result;
	}
}
