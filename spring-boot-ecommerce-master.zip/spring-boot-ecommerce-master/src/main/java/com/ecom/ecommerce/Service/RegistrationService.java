package com.ecom.ecommerce.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecom.ecommerce.model.Admin;
import com.ecom.ecommerce.repository.RegistrationRepository;

@Service
public class RegistrationService {

	
	@Autowired
	private RegistrationRepository repo;
	
	public Admin saveAdmin(Admin admin) {
		return repo.save(admin);
	}
	
	public Admin fetchUserByEmailId(String email) {
	    return repo.findByEmailId(email);
	}
	

	public Admin fetchUserByEmailIdAndPassword(String email,String password) {
	    return	repo.findByEmailIdAndPassword(email, password);
	}
}
