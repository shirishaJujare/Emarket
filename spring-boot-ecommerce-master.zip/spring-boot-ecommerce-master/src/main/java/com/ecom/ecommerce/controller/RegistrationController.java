package com.ecom.ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecom.ecommerce.Service.RegistrationService;
import com.ecom.ecommerce.model.Admin;

@RestController
public class RegistrationController {

	@Autowired
	private RegistrationService service;
	
	@PostMapping("api/registerAdmin")
	@CrossOrigin(origins="http://localhost:4200")
	public Admin registerAdmin(@RequestBody Admin admin) throws Exception {
		String tempEmailId=admin.getEmailId();
		if(tempEmailId != null && ! "".equals(tempEmailId)) {
			Admin  adminobj=service.fetchUserByEmailId(tempEmailId);
			if(adminobj != null) {
				throw new Exception("admin with"+tempEmailId+"is already exists");
			}
		}
		Admin adminobj=null;
		service.saveAdmin(admin);
		return adminobj;
	}
	
	
	@PostMapping("/api/login")
	@CrossOrigin(origins="http://localhost:4200")
	public Admin loginAdmin(@RequestBody Admin admin) throws Exception {
		
		String tempEmailId=admin.getEmailId();
		String tempPass= admin.getPassword();
		Admin adminobj=null;
		
		if(tempEmailId !=null && tempPass!=null) {
		adminobj=service.fetchUserByEmailIdAndPassword(tempEmailId, tempPass);
		}
		if(adminobj == null) {
			throw new Exception("Bad credentials");
		}
		return  adminobj;
	}
	
	
}
