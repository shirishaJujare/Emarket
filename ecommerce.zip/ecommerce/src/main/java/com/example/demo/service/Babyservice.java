package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Register;

import com.example.demo.repository.Babyrepo;

@Service
public class Babyservice {
	
	@Autowired
	Babyrepo repo;

	public Register fetchuserbyemail(String tempemail) {
		
		return  repo.findByEmail(tempemail);
	}

	public Register store(Register register) {
		return repo.save(register);
	}

	public List<Register> getuser() {
		
		List<Register> list=repo.findAll();
		return list;
	}

	public Register fetchuserbyemailandpass(String tempemail, String temppass) {
		return  repo.findByEmailAndPassword(tempemail, temppass);
	}

	public Optional<Register> getcurrentuser(int id) {
		
		return repo.findById(id);
		
	}

}
